clc; 
clear; 
close all;

image = imread('Capture.JPG');

red = image(:,:,1); 
gren = image(:,:,2); 
blue = image(:,:,3); % 

allBlack = zeros(size(image, 1), size(image, 2), 'uint8');
just_red = cat(3, red, allBlack, allBlack);
just_green = cat(3, allBlack, gren, allBlack);
just_blue = cat(3, allBlack, allBlack, blue);

recombinedimage = cat(3, red, gren, blue);

subplot(3, 3, 2);
imshow(image);
fontSize = 20;
subplot(3, 3, 4);
imshow(just_red);
subplot(3, 3, 5);
imshow(just_green)
subplot(3, 3, 6);
imshow(just_blue);
subplot(3, 3, 8);
imshow(recombinedimage);
