clc;
clear all; close all;

im = imread('abcd.jpg');
im1 = rgb2gray(im);
subplot(2,1,1);
imhist(im1);
subplot(2,1,2);
im2 = histeq(im1);
imhist(im2);