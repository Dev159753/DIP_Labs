clc;clear all;close all;
D=[24 54;78 90];
result=svd(D);